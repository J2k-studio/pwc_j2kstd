#!/data/data/com.termux/files/usr/bin/bash
set -e

# ── PowerCode build pipeline (Termux, no Gradle) ──────────────────────

PKG_NAME="com.pwc.app"
APP_NAME="PowerCode"

NDK="$HOME/android-ndk-r29"
ANDROID_JAR="$HOME/android-jar/android.jar"
TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/linux-aarch64/bin"

SRC_JAVA="app/src/main/java"
SRC_CPP="app/src/main/cpp"
SRC_RES="app/src/main/res"
SRC_ASSETS="app/src/main/assets"
MANIFEST="app/src/main/AndroidManifest.xml"

BUILD="build"
OUT_CLASSES="$BUILD/classes"
OUT_JNILIBS="app/src/main/jniLibs/arm64-v8a"
KEYSTORE="debug.keystore"

echo "== [1/6] clean =="
rm -rf "$BUILD"
mkdir -p "$OUT_CLASSES" "$OUT_JNILIBS"

echo "== [2/6] compile native (.so) via NDK =="
if ls "$SRC_CPP"/*.cpp >/dev/null 2>&1; then
    for f in "$SRC_CPP"/*.cpp; do
        name=$(basename "$f" .cpp)
        "$TOOLCHAIN/aarch64-linux-android26-clang++" \
            -shared -fPIC -o "$OUT_JNILIBS/lib${name}.so" \
            "$f" -llog
    done
else
    echo "  (no .cpp files yet, skipping)"
fi

echo "== [3/6] compile java =="
JAVA_FILES=$(find "$SRC_JAVA" -name "*.java")
if [ -n "$JAVA_FILES" ]; then
    javac -classpath "$ANDROID_JAR" -d "$OUT_CLASSES" $JAVA_FILES
else
    echo "  (no .java files yet, skipping)"
fi

echo "== [4/6] dex (d8) =="
if [ -d "$OUT_CLASSES" ] && [ "$(find "$OUT_CLASSES" -name '*.class')" ]; then
    d8 --lib "$ANDROID_JAR" --output "$BUILD" $(find "$OUT_CLASSES" -name "*.class")
else
    echo "  (no classes yet, skipping)"
fi

echo "== [5/6] package resources + link (aapt2) =="
mkdir -p "$BUILD/res-compiled"
if [ -d "$SRC_RES" ]; then
    aapt2 compile --dir "$SRC_RES" -o "$BUILD/res.zip"
fi

AAPT2_LINK_ARGS=(-o "$BUILD/app-unsigned.apk" -I "$ANDROID_JAR" --manifest "$MANIFEST")
[ -f "$BUILD/res.zip" ] && AAPT2_LINK_ARGS+=("$BUILD/res.zip")
[ -d "$SRC_ASSETS" ] && AAPT2_LINK_ARGS+=(-A "$SRC_ASSETS")

aapt2 link "${AAPT2_LINK_ARGS[@]}"

echo "== [5.5/6] inject classes.dex + native libs =="
cd "$BUILD"
[ -f classes.dex ] && zip -j app-unsigned.apk classes.dex
cd - >/dev/null

if [ -d "$OUT_JNILIBS" ] && [ "$(ls -A "$OUT_JNILIBS" 2>/dev/null)" ]; then
    (cd app/src/main && zip -r "../../../$BUILD/app-unsigned.apk" jniLibs)
fi

echo "== [6/6] zipalign + sign =="
zipalign -f 4 "$BUILD/app-unsigned.apk" "$BUILD/app-aligned.apk"

if [ ! -f "$KEYSTORE" ]; then
    echo "  no debug.keystore found, generating one..."
    keytool -genkey -v -keystore "$KEYSTORE" -alias pwcdebug \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass android -keypass android \
        -dname "CN=PowerCode Debug,O=pwc,C=TH"
fi

apksigner sign --ks "$KEYSTORE" --ks-pass pass:android \
    --out "$BUILD/$APP_NAME.apk" "$BUILD/app-aligned.apk"

echo ""
echo "✅ built: $BUILD/$APP_NAME.apk"
